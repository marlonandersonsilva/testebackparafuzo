const restful = require('node-restful')
const mongoose = restful.mongoose

const plateSchema = new mongoose.Schema({
    time: {type: Number, required: true},
    paid: {type:Boolean, required: true},
    left: {type:Boolean, required:true},
amount: { type: Number, min:0 , required: true}
})

module.exports = restful.model('Plate', plateSchema)