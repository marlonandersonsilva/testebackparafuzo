const express = require('express')

module.exports = function(server){

    const router = express.Router()
    server.use('/parking',router)


    const plateService = require('../parking/plates/plateservice')
    plateService.register(router, '/plate')
}